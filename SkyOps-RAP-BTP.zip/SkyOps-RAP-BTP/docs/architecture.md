# Architecture — SAP RAP Flight Booking System

## Overview

This project implements a **Managed RAP Business Object** on **SAP BTP ABAP Environment**.

```
┌─────────────────────────────────────────────────────┐
│                   Fiori Elements UI                  │
│            (List Report + Object Page)              │
└──────────────────────┬──────────────────────────────┘
                       │ OData V4
┌──────────────────────▼──────────────────────────────┐
│              Service Binding (ODATA V4)             │
│            ZUI_FlightBooking_O4                     │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│              Consumption View                       │
│          ZC_FlightBooking (Projection)              │
│    UI Annotations, Search, Value Helps              │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│              Interface View (BO Root)               │
│              ZI_FlightBooking                       │
│    Semantic Annotations, Admin Fields               │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│           Behavior Definition + Implementation      │
│  CRUD | Actions | Validations | Determinations      │
│  Draft Handling | Feature Control                   │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│              Database Table                         │
│              ZFLIGHTBOOKING                         │
│         + Draft Table: ZFLIGHTBOOKING_D             │
└─────────────────────────────────────────────────────┘
```

## RAP BO Design Decisions

| Decision | Choice | Reason |
|---|---|---|
| Key Type | UUID (sysuuid_x16) | Managed RAP generates UUID automatically |
| Implementation | Managed | Less boilerplate, BTP recommended approach |
| Draft | Enabled | Required for Fiori Edit/Save pattern |
| OData Version | V4 | Modern standard, better performance |
| Authorization | #NOT_REQUIRED | Simplified for demo; add PFCG roles in production |

## Booking Status State Machine

```
    ┌─────────┐   BookFlight   ┌────────┐
    │  Open   │ ─────────────► │ Booked │
    │   (O)   │                │  (B)   │
    └─────────┘                └────┬───┘
                                    │ CancelFlight
                               ┌────▼───┐
                               │Cancelled│
                               │  (C)   │
                               └────────┘
```
