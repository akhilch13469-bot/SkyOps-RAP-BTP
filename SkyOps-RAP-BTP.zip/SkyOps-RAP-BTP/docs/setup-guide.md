# Setup Guide — SAP BTP ABAP RAP Flight Booking

## Prerequisites

1. **SAP BTP Trial Account** → [https://cockpit.hanatrial.ondemand.com](https://cockpit.hanatrial.ondemand.com)
2. **ABAP Environment** instance provisioned in BTP cockpit
3. **Eclipse IDE** with ADT (ABAP Development Tools) plugin installed
4. Add your BTP ABAP system in ADT via: `File → New → ABAP Cloud Project`

---

## Step 1: Create the Database Table

1. In ADT, right-click your package → `New → Other ABAP Repository Objects → Dictionary → Database Table`
2. Name: `ZFLIGHTBOOKING`
3. Copy contents from `src/db/ZFLIGHTBOOKING.tabl.abap`
4. Activate (`Ctrl+F3`)

> For Draft: Create `ZFLIGHTBOOKING_D` using the **Draft Table Generator** (right-click table → Generate Draft Table)

---

## Step 2: Create Interface CDS View

1. `New → Other → Core Data Services → Data Definition`
2. Name: `ZI_FLIGHTBOOKING`, Template: **Define Root View Entity**
3. Paste contents from `src/cds/ZI_FlightBooking.ddls.asddls`
4. Activate

---

## Step 3: Create Consumption CDS View

1. `New → Data Definition`
2. Name: `ZC_FLIGHTBOOKING`, Template: **Define Root View Entity as Projection**
3. Paste contents from `src/cds/ZC_FlightBooking.ddls.asddls`
4. Activate

---

## Step 4: Create Behavior Definition

1. Right-click `ZI_FLIGHTBOOKING` → `New Behavior Definition`
2. Implementation Type: **Managed**
3. Paste contents from `src/behavior/ZI_FlightBooking.bdef.asbdef`
4. Click the **Quick Fix** link to auto-generate the implementation class skeleton
5. Activate

---

## Step 5: Implement Behavior Class

1. Open the generated class `ZBP_FLIGHTBOOKING`
2. Replace the content with `src/behavior/ZBP_FlightBooking.clas.abap`
3. Activate

---

## Step 6: Create Service Definition & Binding

**Service Definition:**
1. `New → Other → Business Services → Service Definition`
2. Name: `ZUI_FLIGHTBOOKING_O4`
3. Content:
```abap
@EndUserText.label: 'Flight Booking Service'
define service ZUI_FlightBooking_O4 {
  expose ZC_FlightBooking as FlightBooking;
}
```

**Service Binding:**
1. Right-click Service Definition → `New Service Binding`
2. Name: `ZUI_FLIGHTBOOKING_O4`, Binding Type: **OData V4 - UI**
3. Click **Publish** (Local)
4. Click **Preview** to open Fiori Elements app

---

## Step 7: Run Unit Tests

1. Right-click `ZTEST_FLIGHTBOOKING` → `Run As → ABAP Unit Test`
2. Check results in the ABAP Unit Test view

---

## Testing the OData Service

Your service endpoint will be:
```
https://<your-btp-host>/sap/opu/odata4/sap/zui_flightbooking_o4/srvd/sap/zui_flightbooking_o4/0001/
```

Test with REST client or Postman:
```http
GET /FlightBooking HTTP/1.1
Host: <your-btp-host>
Authorization: Basic <base64-credentials>
```

---

## Common Issues

| Issue | Fix |
|---|---|
| Activation error on CDS view | Check spelling of field names matches DB table |
| Draft table not found | Run Draft Table Generator on main table |
| 401 Unauthorized on OData | Check user has `SAP_BR_DEVELOPER` role |
| Action not visible in Fiori | Check feature control returns `fc-o-enabled` |
