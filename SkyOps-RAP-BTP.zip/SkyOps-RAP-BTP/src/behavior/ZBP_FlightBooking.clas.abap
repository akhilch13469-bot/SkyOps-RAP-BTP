CLASS zbp_flightbooking DEFINITION
  PUBLIC
  ABSTRACT
  FINAL
  FOR BEHAVIOR OF zi_flightbooking.

ENDCLASS.

CLASS zbp_flightbooking IMPLEMENTATION.
ENDCLASS.

"=======================================================================
" LOCAL HANDLER CLASS
"=======================================================================
CLASS lhc_flightbooking DEFINITION INHERITING FROM cl_abap_behavior_handler.

  PRIVATE SECTION.

    METHODS:
      " Custom Actions
      bookflight   FOR MODIFY
        IMPORTING keys FOR ACTION flightbooking~bookflight RESULT result,
      cancelflight FOR MODIFY
        IMPORTING keys FOR ACTION flightbooking~cancelflight RESULT result,

      " Determinations
      setbookingid     FOR DETERMINE ON MODIFY
        IMPORTING keys FOR flightbooking~setbookingid,
      calculatetotalprice FOR DETERMINE ON MODIFY
        IMPORTING keys FOR flightbooking~calculatetotalprice,
      setdefaultstatus FOR DETERMINE ON MODIFY
        IMPORTING keys FOR flightbooking~setdefaultstatus,

      " Validations
      validateflightdate  FOR VALIDATE ON SAVE
        IMPORTING keys FOR flightbooking~validateflightdate,
      validateseatnumber  FOR VALIDATE ON SAVE
        IMPORTING keys FOR flightbooking~validateseatnumber,
      validatepassengeremail FOR VALIDATE ON SAVE
        IMPORTING keys FOR flightbooking~validatepassengeremail,

      " Feature Control
      get_instance_features FOR INSTANCE FEATURES
        IMPORTING keys REQUEST requested_features FOR flightbooking RESULT result.

ENDCLASS.

CLASS lhc_flightbooking IMPLEMENTATION.

  " ─────────────────────────────────────────────────────────────
  " ACTION: Book Flight (O → B)
  " ─────────────────────────────────────────────────────────────
  METHOD bookflight.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( bookingstatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings)
      FAILED failed.

    " Filter only Open bookings
    DATA(lt_open) = lt_bookings->filter(
      WHERE bookingstatus = 'O' ).

    IF lt_open IS INITIAL.
      RETURN.
    ENDIF.

    " Update status to Booked
    MODIFY ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        UPDATE FIELDS ( bookingstatus )
        WITH VALUE #( FOR b IN lt_open (
          %tky           = b-%tky
          bookingstatus  = 'B'
        ) )
      REPORTED DATA(lt_reported).

    " Return updated entities
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).

    result = VALUE #( FOR r IN lt_result (
      %tky   = r-%tky
      %param = r
    ) ).
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " ACTION: Cancel Flight (B → C)
  " ─────────────────────────────────────────────────────────────
  METHOD cancelflight.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( bookingstatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings)
      FAILED failed.

    DATA(lt_booked) = lt_bookings->filter(
      WHERE bookingstatus = 'B' ).

    IF lt_booked IS INITIAL.
      RETURN.
    ENDIF.

    MODIFY ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        UPDATE FIELDS ( bookingstatus )
        WITH VALUE #( FOR b IN lt_booked (
          %tky           = b-%tky
          bookingstatus  = 'C'
        ) )
      REPORTED DATA(lt_reported).

    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).

    result = VALUE #( FOR r IN lt_result (
      %tky   = r-%tky
      %param = r
    ) ).
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " DETERMINATION: Auto-generate BookingID
  " ─────────────────────────────────────────────────────────────
  METHOD setbookingid.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( bookingid )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings).

    " Only set for new records (BookingID = 0)
    DATA(lt_new) = lt_bookings->filter( WHERE bookingid = '00000000' ).
    IF lt_new IS INITIAL. RETURN. ENDIF.

    " Get max existing ID from DB
    SELECT MAX( booking_id ) FROM zflightbooking INTO @DATA(lv_max_id).
    lv_max_id += 1.

    MODIFY ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        UPDATE FIELDS ( bookingid )
        WITH VALUE #( FOR b IN lt_new (
          %tky      = b-%tky
          bookingid = lv_max_id
        ) )
      REPORTED DATA(lt_reported).
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " DETERMINATION: Calculate Total Price based on Airline/Flight
  " ─────────────────────────────────────────────────────────────
  METHOD calculatetotalprice.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( airlineid flightnumber flightdate )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings).

    " Read base prices from SFLIGHT (standard demo table)
    LOOP AT lt_bookings REFERENCE INTO DATA(lr_booking).
      SELECT SINGLE price, currency
        FROM sflight
        WHERE carrid = @lr_booking->airlineid
          AND connid = @lr_booking->flightnumber
          AND fldate = @lr_booking->flightdate
        INTO @DATA(ls_flight).

      IF sy-subrc = 0.
        MODIFY ENTITIES OF zi_flightbooking IN LOCAL MODE
          ENTITY flightbooking
            UPDATE FIELDS ( totalprice currencycode )
            WITH VALUE #( (
              %tky         = lr_booking->%tky
              totalprice   = ls_flight-price
              currencycode = ls_flight-currency
            ) )
          REPORTED DATA(lt_reported).
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " DETERMINATION: Set default status = Open
  " ─────────────────────────────────────────────────────────────
  METHOD setdefaultstatus.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( bookingstatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings).

    MODIFY ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        UPDATE FIELDS ( bookingstatus )
        WITH VALUE #( FOR b IN lt_bookings
          WHERE ( bookingstatus IS INITIAL ) (
            %tky          = b-%tky
            bookingstatus = 'O'
          ) )
      REPORTED DATA(lt_reported).
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " VALIDATION: Flight Date must be in the future
  " ─────────────────────────────────────────────────────────────
  METHOD validateflightdate.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( flightdate )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings).

    LOOP AT lt_bookings INTO DATA(ls_booking).
      IF ls_booking-flightdate <= sy-datum.
        APPEND VALUE #(
          %tky = ls_booking-%tky
        ) TO failed-flightbooking.

        APPEND VALUE #(
          %tky        = ls_booking-%tky
          %state_area = 'VALIDATE_DATE'
          %msg        = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text     = 'Flight date must be in the future'
          )
          %element-flightdate = if_abap_behv=>mk-on
        ) TO reported-flightbooking.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " VALIDATION: Seat number format (e.g., 12A, 3C)
  " ─────────────────────────────────────────────────────────────
  METHOD validateseatnumber.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( seatnumber )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings).

    LOOP AT lt_bookings INTO DATA(ls_booking).
      " Simple validation: must not be empty
      IF ls_booking-seatnumber IS INITIAL.
        APPEND VALUE #( %tky = ls_booking-%tky ) TO failed-flightbooking.
        APPEND VALUE #(
          %tky        = ls_booking-%tky
          %state_area = 'VALIDATE_SEAT'
          %msg        = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text     = 'Seat number is required'
          )
          %element-seatnumber = if_abap_behv=>mk-on
        ) TO reported-flightbooking.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " VALIDATION: Email format check
  " ─────────────────────────────────────────────────────────────
  METHOD validatepassengeremail.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( passengeremail )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings).

    LOOP AT lt_bookings INTO DATA(ls_booking).
      " Must contain @ and .
      IF NOT ls_booking-passengeremail CA '@' OR
         NOT ls_booking-passengeremail CA '.'.
        APPEND VALUE #( %tky = ls_booking-%tky ) TO failed-flightbooking.
        APPEND VALUE #(
          %tky        = ls_booking-%tky
          %state_area = 'VALIDATE_EMAIL'
          %msg        = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text     = 'Please enter a valid email address'
          )
          %element-passengeremail = if_abap_behv=>mk-on
        ) TO reported-flightbooking.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  " ─────────────────────────────────────────────────────────────
  " FEATURE CONTROL: Disable BookFlight if already Booked/Cancelled
  " ─────────────────────────────────────────────────────────────
  METHOD get_instance_features.
    READ ENTITIES OF zi_flightbooking IN LOCAL MODE
      ENTITY flightbooking
        FIELDS ( bookingstatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings)
      FAILED failed.

    result = VALUE #( FOR b IN lt_bookings (
      %tky              = b-%tky
      %action-bookflight =
        COND #( WHEN b-bookingstatus = 'O'
                THEN if_abap_behv=>fc-o-enabled
                ELSE if_abap_behv=>fc-o-disabled )
      %action-cancelflight =
        COND #( WHEN b-bookingstatus = 'B'
                THEN if_abap_behv=>fc-o-enabled
                ELSE if_abap_behv=>fc-o-disabled )
    ) ).
  ENDMETHOD.

ENDCLASS.
