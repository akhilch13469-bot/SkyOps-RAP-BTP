@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Flight Booking - Consumption View'

@UI.headerInfo: {
  typeName: 'Flight Booking',
  typeNamePlural: 'Flight Bookings',
  title: { type: #STANDARD, value: 'BookingID' },
  description: { type: #STANDARD, value: 'PassengerName' }
}

@Search.searchable: true

define root view entity ZC_FlightBooking
  provider contract transactional_query
  as projection on ZI_FlightBooking
{
      @UI.facet: [
        { id: 'BookingDetails', purpose: #STANDARD, type: #IDENTIFICATION_REFERENCE,
          label: 'Booking Details', position: 10 }
      ]

  key BookingUUID,

      @UI.lineItem: [{ position: 10 }]
      @UI.identification: [{ position: 10 }]
      BookingID,

      @UI.lineItem: [{ position: 20 }]
      @UI.identification: [{ position: 20 }]
      @Search.defaultSearchElement: true
      AirlineID,

      @UI.lineItem: [{ position: 30 }]
      @UI.identification: [{ position: 30 }]
      FlightNumber,

      @UI.lineItem: [{ position: 40 }]
      @UI.identification: [{ position: 40 }]
      FlightDate,

      @UI.lineItem: [{ position: 50 }]
      @UI.identification: [{ position: 50 }]
      @Search.defaultSearchElement: true
      PassengerName,

      @UI.identification: [{ position: 60 }]
      PassengerEmail,

      @UI.lineItem: [{ position: 70 }]
      @UI.identification: [{ position: 70 }]
      SeatNumber,

      @UI.lineItem: [{ position: 80, criticality: 'BookingStatusCriticality' }]
      @UI.identification: [{ position: 80 }]
      BookingStatus,

      case BookingStatus
        when 'B' then 3   -- positive (green)
        when 'C' then 1   -- negative (red)
        else 2            -- critical (orange)
      end                 as BookingStatusCriticality,

      @UI.lineItem: [{ position: 90 }]
      @Semantics.amount.currencyCode: 'CurrencyCode'
      TotalPrice,

      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_Currency', element: 'Currency' } }]
      CurrencyCode,

      @UI.lineItem: [{ position: 100,
        label: 'Actions',
        type: #FOR_ACTION, dataAction: 'BookFlight',
        button.emphasized: true }]
      BookingUUID  -- reused field to attach action button

}
