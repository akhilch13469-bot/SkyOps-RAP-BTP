@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Flight Booking - Interface View (RAP BO Root)'

define root view entity ZI_FlightBooking
  as select from zflightbooking
{
  key booking_uuid          as BookingUUID,
      booking_id            as BookingID,
      airline_id            as AirlineID,
      flight_number         as FlightNumber,
      flight_date           as FlightDate,
      passenger_name        as PassengerName,
      passenger_email       as PassengerEmail,
      seat_number           as SeatNumber,
      booking_status        as BookingStatus,
      total_price           as TotalPrice,
      currency_code         as CurrencyCode,

      @Semantics.user.createdBy: true
      created_by            as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      created_at            as CreatedAt,
      @Semantics.user.lastChangedBy: true
      last_changed_by       as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt
}
